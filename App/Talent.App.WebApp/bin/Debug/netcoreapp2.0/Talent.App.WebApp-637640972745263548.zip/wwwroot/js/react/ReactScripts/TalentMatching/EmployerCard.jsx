﻿import React from 'react';

export default class EmployerCard extends React.Component {
    constructor(props) {
        super(props);

    }

    render() {
 
    }
}