﻿import React from 'react'
import Cookies from 'js-cookie'
import { BodyWrapper, loaderData } from '../Layout/BodyWrapper.jsx'
import TalentCard from '../TalentFeed/TalentCard.jsx'

export default class TalentWatchlist extends React.Component {
    constructor(props) {
        super(props)

        //let loader = loaderData
        //loader.allowedUsers.push("Employer")
        //loader.allowedUsers.push("Recruiter")

        //this.state = {
        //    loaderData: loader
        //}

    }   

    //loadWatchlist()   url: 'https://talent-listing.azurewebsites.net/listing/listing/getWatchlist',
 
    render() {
       
      
        //return (
        //    <BodyWrapper reload={this.init} loaderData={this.state.loaderData} >
             
        //    </BodyWrapper>
        //)
    }
}