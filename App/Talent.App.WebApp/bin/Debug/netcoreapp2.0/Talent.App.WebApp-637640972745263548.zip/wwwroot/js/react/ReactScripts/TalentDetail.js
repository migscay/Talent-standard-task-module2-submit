﻿import React from 'react';
import ReactDOM from 'react-dom';
import TalentDetail from './TalentFeed/TalentDetail.jsx';

ReactDOM.render(
    <TalentDetail />,
    document.getElementById('talent-detail-wrapper')
)