﻿import React from 'react';
import ReactDOM from 'react-dom';
import ServiceListing from './Listing/ServiceListing.jsx';

ReactDOM.render(
    <ServiceListing />,
    document.getElementById('service-listing-section')
)