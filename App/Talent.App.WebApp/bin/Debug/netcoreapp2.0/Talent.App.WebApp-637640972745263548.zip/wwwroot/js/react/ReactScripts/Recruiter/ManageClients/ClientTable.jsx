﻿/*This component renders table on ManageClient*/

import React from 'react'
import { Button, Icon, Table, Popup } from 'semantic-ui-react'
const statusText = ["Created", "Sent", "Active"]

class ClientTable extends React.Component {
    constructor(props) {
        super(props);

    
    };

   
    render() {
        
    
    }
}

export default ClientTable