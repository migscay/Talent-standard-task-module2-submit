﻿import React from 'react';
import ReactDOM from 'react-dom';
import ServiceDetails from './Service/ServiceDetails.jsx';

ReactDOM.render(
    <ServiceDetails />,
    document.getElementById('service-detail-section')
)