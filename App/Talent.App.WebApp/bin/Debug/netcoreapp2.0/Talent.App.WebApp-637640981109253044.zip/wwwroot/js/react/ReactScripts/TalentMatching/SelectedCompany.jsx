﻿import React from 'react';
import ReactDOM from 'react-dom';
import Cookies from 'js-cookie';
import JobListingCard from './JobListingCard.jsx';

export default class SelectedCompany extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
       
   
    }
}